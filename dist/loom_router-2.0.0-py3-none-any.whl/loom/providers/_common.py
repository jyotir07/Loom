"""Shared helpers used across provider modules."""

from __future__ import annotations

import base64
import os
from typing import Any

import requests

from loom import _context
from loom.errors import AuthError


def require_env(name: str) -> str:
    """Return the API key for `name` or raise AuthError if missing/blank.

    Resolution order:
      1. Programmatic api_keys passed into Loom(api_keys=...) — checked via
         the active LoomContext.
      2. The process environment variable of the same name.
      3. The configured KeyVault (if any) on the active LoomContext.
    """
    ctx = _context.current()
    if ctx is not None:
        override = (ctx.api_keys.get(name) or "").strip()
        if override:
            return override
    value = (os.getenv(name) or "").strip()
    if value:
        return value
    if ctx is not None and ctx.vault is not None:
        vault_value = ctx.vault.get(name)
        if vault_value:
            vault_value = vault_value.strip()
            if vault_value:
                return vault_value
    raise AuthError(f"environment variable {name} is required but not set")


def fetch_image_b64(url: str, timeout: float = 60.0) -> dict[str, str]:
    """Download an image and return it as the unified image payload."""
    resp = requests.get(url, timeout=timeout)
    resp.raise_for_status()
    mime = resp.headers.get("Content-Type", "image/png").split(";")[0].strip()
    return {
        "mime_type": mime,
        "data_b64": base64.b64encode(resp.content).decode("ascii"),
    }


def image_payload(*, mime_type: str, data_b64: str) -> dict[str, str]:
    return {"mime_type": mime_type, "data_b64": data_b64}


def text_response(text: str) -> dict[str, Any]:
    return {"kind": "text", "text": text}


def image_response(images: list[dict[str, str]]) -> dict[str, Any]:
    return {"kind": "image", "images": images}
